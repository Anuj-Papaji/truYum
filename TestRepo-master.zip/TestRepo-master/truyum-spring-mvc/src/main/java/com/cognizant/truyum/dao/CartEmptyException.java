package com.cognizant.truyum.dao;


public class CartEmptyException extends Exception {

}