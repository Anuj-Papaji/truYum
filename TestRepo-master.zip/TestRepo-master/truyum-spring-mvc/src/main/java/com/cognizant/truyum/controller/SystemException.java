package com.cognizant.truyum.controller;

public class SystemException extends Exception {

}
