package com.cognizant.truyum.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionHandler {
	private static Connection con = null;
	//private static Properties props = new Properties();

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		//FileInputStream fis = null;
		//fis = new FileInputStream("resources/connection.properties");
		//props.load(fis);
		// load the Driver Class
		//Class.forName(props.getProperty("driver"));
		// create the connection now
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/truyum","root","");

		return con;

	}
/*
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		System.out.println(ConnectionHandler.getConnection());
	}*/
}