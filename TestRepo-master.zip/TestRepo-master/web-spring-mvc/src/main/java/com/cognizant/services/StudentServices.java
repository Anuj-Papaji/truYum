package com.cognizant.services;

import org.springframework.stereotype.Service;

@Service
public class StudentServices {

}
